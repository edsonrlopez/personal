﻿/*
 * Harris Computer
 * Drink Code Demo
 * Created by Edson R. Lopez
 * Date: 4/25/2023
 * Time: 7:24 AM
 * Compiler: Microsoft VS Community 2022 v17.5
 */
using System;
using System.Collections.Generic;

namespace DrinkCodeSample
{

	class Program
	{
		public static void Main(string[] args)
		{
			List<BaseDrinkClass> drinks=new List<BaseDrinkClass>();
            JuiceClass juice = new JuiceClass ("Orange Juice","oranges",false );
            drinks.Add(juice);
            BeerClass beer = new BeerClass("Budweiser", true,5);
            drinks.Add(beer);
            SodaClass soda = new SodaClass("Pepsi", true);
            drinks.Add(soda);

			Console.WriteLine("********************************************");
            Console.WriteLine("*             Harris Computer              *");
            Console.WriteLine("*           Drink Code Demo v1.0           *");
            Console.WriteLine("*        Created  by Edson R. Lopez        *");
            Console.WriteLine("*    Last Modified:  4/25/2023  4:00pm     *");
            Console.WriteLine("********************************************");
            Console.WriteLine();
            Console.WriteLine("Drink List:");
            for (int i=0;i<drinks.Count;i++) {
				Console.WriteLine("({0}) {1}",i+1,drinks[i].Description());
			} //for
			Console.ReadKey(true);
		} //main function
	} //class Program
} //namespace

