﻿/*
 * Harris Computer
 * Drink Code Demo
 * Created by Edson R. Lopez
 * Date: 4/25/2023
 * Time: 8:05 AM
 * Compiler: Microsoft VS Community 2022 v17.5
 */
using System;
using System.Collections.Generic;

namespace DrinkCodeSample
{
	public class BaseDrinkClass {
		protected string sDrinkName="";       //Drink Name
		protected bool   bCarbonated=false;   //Carbonated True of False
		
		public virtual string Description() //Overrided in the child classes
        {
			return "";
        }
	} //BaseDrinkClass
	
	class JuiceClass : BaseDrinkClass
    {
	 	
        private string sMadeFrom;

        public JuiceClass(string sName,string sMade,bool bCarbo) //Constructor
        {
            sDrinkName = sName;
            sMadeFrom = sMade;
            bCarbonated = bCarbo;
        }
        public override string Description()
        {
            string sRes = "";
            sRes =sDrinkName;
        	if (bCarbonated) sRes=sRes+", carbonated"; else sRes=sRes+", not carbonated";
        	sRes=sRes+", made from "+sMadeFrom;
        	return sRes;
        }
    } //JuiceClass
	class BeerClass : BaseDrinkClass
    {
        private int iAlcoholContent;
        public BeerClass(string sName, bool bCarbo,int iAlohol) //Constructor
        {
            sDrinkName = sName;
            iAlcoholContent = iAlohol;
            bCarbonated = bCarbo;
        }
        public override string Description()
        {
            string sRes = "";
            sRes =sDrinkName;
        	if (bCarbonated) sRes=sRes+", carbonated"; else sRes=sRes+", not carbonated";
        	sRes=sRes+", "+iAlcoholContent.ToString()+"%";
        	return sRes;
        }
    } //BeerClass
	
	class SodaClass : BaseDrinkClass
    {
        public SodaClass(string sName, bool bCarbo) //Constructor
        {
            sDrinkName = sName;
            bCarbonated = bCarbo;
        }
        public override string Description()
        {
            string sRes = "";
            sRes =sDrinkName;
        	if (bCarbonated) sRes=sRes+", carbonated"; else sRes=sRes+", not carbonated";
        	return sRes;
        }
    } //SodaClass
	
} //namespace
