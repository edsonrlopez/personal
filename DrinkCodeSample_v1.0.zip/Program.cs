﻿/*
 * Harris Computer
 * Drink Code Demo
 * Created by Edson R. Lopez
 * Date: 4/25/2023
 * Time: 7:24 AM
 * Compiler: Microsoft VS Community 2022 v17.5
 */
using System;
using System.Collections.Generic;

namespace DrinkCodeSample
{

	class Program
	{
		public static void Main(string[] args)
		{
			List<BaseDrinkClass> Drinks=new List<BaseDrinkClass>();
            JuiceClass Juice = new JuiceClass ("Orange Juice","oranges",false );
            Drinks.Add(Juice);
            BeerClass Beer = new BeerClass("Budweiser", true,5);
            Drinks.Add(Beer);
            SodaClass Soda = new SodaClass("Pepsi", true);
            Drinks.Add(Soda);

			Console.WriteLine("********************************************");
            Console.WriteLine("*             Harris Computer              *");
            Console.WriteLine("*           Drink Code Demo v1.0           *");
            Console.WriteLine("*        Created  by Edson R. Lopez        *");
            Console.WriteLine("*    Last Modified:  4/25/2023  6:00pm     *");
            Console.WriteLine("********************************************");
            Console.WriteLine();
            Console.WriteLine("Drink List:");
            for (int i=0;i<Drinks.Count;i++) {
				Console.WriteLine("({0}) {1}",i+1,Drinks[i].Description());
			} //for
			Console.ReadKey(true);
		} //main function
	} //class Program
} //namespace

